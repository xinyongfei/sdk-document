package com.shoufuyou.sdk;

public class TradeQueryResponse extends TradeResponse {
    private int orderAmount;

    public int getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
    }
}
