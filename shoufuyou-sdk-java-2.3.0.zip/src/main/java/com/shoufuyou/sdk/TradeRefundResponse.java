package com.shoufuyou.sdk;

public class TradeRefundResponse extends TradeResponse {
    private int refundAmount;

    public int getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(int refundAmount) {
        this.refundAmount = refundAmount;
    }
}
