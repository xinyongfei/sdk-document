using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Collections.Generic;
using System.Drawing;
using System.Web.UI.WebControls;

namespace Newtonsoft.Json
{
	internal static class JavaScriptUtils
	{
		public static string QuoteJScriptString(string value)
		{
			return QuoteJScriptString(value, false, '\'');
		}

		public static string QuoteJScriptString(string value, char delimiter)
		{
			return QuoteJScriptString(value, false, delimiter);
		}

		// this method is modified from Microsoft's System.Web.UI.Util.QuoteJScriptString method
		public static string QuoteJScriptString(string value, bool forUrl, char delimiter)
		{
			StringBuilder builder1 = null;
			if (string.IsNullOrEmpty(value))
			{
				return string.Empty;
			}
			int num1 = 0;
			int num2 = 0;
			for (int num3 = 0; num3 < value.Length; num3++)
			{
				char ch1 = value[num3];
				if (ch1 <= '"')
				{
					switch (ch1)
					{
						case '\t':
							{
								goto Label_00B0;
							}
						case '\n':
							{
								goto Label_0185;
							}
						case '\v':
						case '\f':
							{
								goto Label_01EE;
							}
						case '\r':
							{
								goto Label_007A;
							}
						case '"':
							{
								if (delimiter == '"')
									goto Label_00E6;
								else
									goto Label_01EE;
							}
					}
					goto Label_01EE;
				}
				switch (ch1)
				{
					case '%':
						{
							if (!forUrl)
							{
								goto Label_01EE;
							}
							if (builder1 == null)
							{
								builder1 = new StringBuilder(value.Length + 6);
							}
							if (num2 > 0)
							{
								builder1.Append(value, num1, num2);
							}
							builder1.Append("%25");
							num1 = num3 + 1;
							num2 = 0;
							goto Label_01F2;
						}
					case '&':
						{
							goto Label_01EE;
						}
					case '\'':
						{
							if (delimiter == '\'')
							{
								if (builder1 == null)
								{
									builder1 = new StringBuilder(value.Length + 5);
								}
								if (num2 > 0)
								{
									builder1.Append(value, num1, num2);
								}
								builder1.Append(@"\'");
								num1 = num3 + 1;
								num2 = 0;
								goto Label_01F2;
							}
							else
							{
								goto Label_01EE;
							}
						}
					case '\\':
						{
							if (builder1 == null)
							{
								builder1 = new StringBuilder(value.Length + 5);
							}
							if (num2 > 0)
							{
								builder1.Append(value, num1, num2);
							}
							builder1.Append(@"\\");
							num1 = num3 + 1;
							num2 = 0;
							goto Label_01F2;
						}
					default:
						{
							goto Label_01EE;
						}
				}
			Label_007A:
				if (builder1 == null)
				{
					builder1 = new StringBuilder(value.Length + 5);
				}
				if (num2 > 0)
				{
					builder1.Append(value, num1, num2);
				}
				builder1.Append(@"\r");
				num1 = num3 + 1;
				num2 = 0;
				goto Label_01F2;
			Label_00B0:
				if (builder1 == null)
				{
					builder1 = new StringBuilder(value.Length + 5);
				}
				if (num2 > 0)
				{
					builder1.Append(value, num1, num2);
				}
				builder1.Append(@"\t");
				num1 = num3 + 1;
				num2 = 0;
				goto Label_01F2;
			Label_00E6:
				if (builder1 == null)
				{
					builder1 = new StringBuilder(value.Length + 5);
				}
				if (num2 > 0)
				{
					builder1.Append(value, num1, num2);
				}
				builder1.Append("\\\"");
				num1 = num3 + 1;
				num2 = 0;
				goto Label_01F2;
			Label_0185:
				if (builder1 == null)
				{
					builder1 = new StringBuilder(value.Length + 5);
				}
				if (num2 > 0)
				{
					builder1.Append(value, num1, num2);
				}
				builder1.Append(@"\n");
				num1 = num3 + 1;
				num2 = 0;
				goto Label_01F2;
			Label_01EE:
				num2++;
			Label_01F2: ;
			}
			if (builder1 == null)
			{
				return value;
			}
			if (num2 > 0)
			{
				builder1.Append(value, num1, num2);
			}
			return builder1.ToString();
		}
	}
}