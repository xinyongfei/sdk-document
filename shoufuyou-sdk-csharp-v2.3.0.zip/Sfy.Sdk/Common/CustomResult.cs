﻿
namespace Sfy.Skd
{
    internal class CustomResult
    {
        /// <summary>
        /// 是否成功
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// 返回的结果码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 返回结果码对应的字符串解释
        /// </summary>
        public string Message { get; set; }
    }
}
