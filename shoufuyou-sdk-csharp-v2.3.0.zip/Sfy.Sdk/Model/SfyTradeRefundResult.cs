﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sfy.Sdk
{
    public class SfyTradeRefundResult
    {
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string MerchantOrderId { get; set; }

        /// <summary>
        /// 首付游交易号
        /// </summary>
        public string TradeNumber { get; set; }
    }
}
