﻿using System;
using System.Collections.Generic;

namespace Sfy.Sdk
{
    /// <summary>
    /// 首付游收单接口（网关模式）
    /// </summary>
    internal sealed class TradeCreateSync : RequestBase<string, string>
    {
        /// <summary>
        /// 商户请求首付游生成首付游交易单。
        /// </summary>
        /// <param name="reqContent"></param>
        /// <returns></returns>
        protected override string DoDeal(string reqContent)
        {
            throw new NotImplementedException();
        }

        #region 【查检请求数据参数】

        /// <summary>
        /// 
        /// </summary>
        private static readonly Dictionary<string, string> Dicts = new Dictionary<string, string>()
        {
            {"merchant_order_id","商户订单号"},
            //{"product_type","产品类型"},
            {"product_name","产品名称"},
            {"order_amount","订单总价"},
            //{"time_limit","订单有效时长"},
            {"tourist_adult_number","出行人数"},
            //{"departure","出发城市"},
            //{"arrival","目的地城市"},
            //{"departure_date","出发日期"},
            //{"return_date","返程日期"},
            //{"source_type","订单来源类型"},
            //{"emergency_name","紧急联系人姓名"},
            //{"emergency_mobile","紧急联系人手机"},
            {"return_url","回调地址"},
            //{"notify_url","通知地址"},
            //{"tourists","出行人列表"}
        };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        protected override SfyCustomResult CheckReqParamters(Dictionary<string, object> reqParams)
        {
            var header = this.CheckHeaderParamters();
            if (!header.IsSuccess) return header;

            var result = new SfyCustomResult()
            {
                Code = "20001"
            };

            if (reqParams == null || reqParams.Count <= 0)
            {
                result.Message = "请求的收单接口参数不能为空.";
                return result;
            }

            foreach (var dict in Dicts)
            {
                switch (dict.Key)
                {
                    case "order_amount":           // 订单总价
                    case "time_limit":      // 订单有效时长
                    case "tourist_adult_number":  // 出行人数
                        if (SfyUtil.IsEmptyInt(result, reqParams, dict))
                        {
                            return result;
                        }
                        break;
                    case "tourists":        // 出行人列表
                        

                        break;
                    default:
                        if (SfyUtil.IsEmptyStr(result, reqParams, dict))
                        {
                            return result;
                        }
                        
                        break;
                }
            }
            result.IsSuccess = true;
            return result;
        }
        #endregion
    }
}
