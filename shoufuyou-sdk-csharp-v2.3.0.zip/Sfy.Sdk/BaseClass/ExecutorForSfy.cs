﻿using System;
using System.Collections.Generic;

namespace Sfy.Sdk
{
    /// <summary>
    /// 商家发起的请求处理
    /// </summary>
    internal class ExecutorForSfy<T> : ExecutorBase<Dictionary<string, object>, T>
    {
        /// <summary>
        /// 
        /// </summary>
        protected RequestBase<string, string> reqObject = null;
        
        /// <summary>
        /// 调用接口内容处理
        /// </summary>
        /// <param name="reqParams"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        protected override SfyRspResult<T> DoHandle(Dictionary<string, object> reqParams, ReqType reqType)
        {
            switch (reqType)
            {
                case ReqType.TradeCreate: // 请款接口
                    reqObject = new TradeCreateSync();
                    break;
                case ReqType.TradeLoan: // 请款接口
                    reqObject = new TradeLoanSync();
                    break;
                case ReqType.TradeQuery: // 订单查询接口
                    reqObject = new TradeQuerySync();
                    break;
                case ReqType.TradeRefund: // 退款接口
                    reqObject = new TradeRefundSync();
                    break;
            }

            return reqObject.Deal<T>(reqParams, reqType);
        }

        #region 构造默认的应答
        /// <summary>
        /// 构造默认的应答
        /// </summary>
        /// <param name="errorCode"></param>
        /// <param name="errorMsg"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        public override SfyRspResult<T> GetDefaultResult(string errorCode, string errorMsg, ReqType reqType)
        {
            var result = new SfyRspResult<T>()
            {
                Code = errorCode,
                Message = errorMsg
            };

            //switch (reqType)
            //{
            //    case ReqType.TradeCreate:

            //        break;
            //    case ReqType.TradeLoan:

            //        break;
            //    case ReqType.TradeQuery:

            //        break;
            //    case ReqType.TradeRefund:

            //        break;
            //}
            return result;
        }
        #endregion
    }
}
