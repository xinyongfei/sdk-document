﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;

namespace Sfy.Sdk
{
    /// <summary>
    /// 接口报文内容处理基类
    /// </summary>
    /// <typeparam name="TOutput"></typeparam>
    /// <typeparam name="TInput"></typeparam>
    internal abstract class RequestBase<TInput, TOutput>
    {
        #region 报文内容处理
        /// <summary>
        /// 报文内容处理
        /// </summary>
        /// <param name="reqObject">接口接收到的报文</param>
        /// <returns>处理结果报文</returns>
        public TOutput Deal(TInput reqObject)
        {
            var hd = new HandleDelegate(DoDeal);

            return hd(reqObject);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqParams"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        public virtual SfyRspResult<T> Deal<T>(Dictionary<string, object> reqParams, ReqType reqType)
        {
            var result = new SfyRspResult<T>();

            // 查检请求参数
            var reqResult = this.CheckReqParamters(reqParams);
            if (!reqResult.IsSuccess)
            {
                result.Code = reqResult.Code;
                result.Message = reqResult.Message;
                return result;
            }

            var reqContent = SfyUtil.Encrypt(reqParams);
            var sourceType = "pc";
            if (reqParams.ContainsKey("source_type"))
            {
                sourceType = reqParams["source_type"].ToString();
            }

            if (reqType == ReqType.TradeCreate)
            {
                result.IsSuccess = HttpHelper.SubmitForm(reqContent, reqType, sourceType);
                result.Code = "10000";
                result.Message = "请求成功";
                return result;
            }

            var rspResult = HttpHelper.Post(reqContent, reqType);
            
            if (!SfyUtil.CheckSign(rspResult))
            {
                result.Code = "10002";
                result.Message = "返回的应答签名错误";
                return result;
            }

            var bizContent = SfyUtil.Decrypt(rspResult.biz_content);
            var rspObj = JavaScriptConvert.Deserialize<JsonResult>(bizContent);
            if (rspObj == null)
            {
                result.Code = "10011";//TODO
                result.Message = "解析返回应答数据为空.";
                return result;
            }
            result.Code = rspObj.code;
            if (rspObj.code != "10000")
            {
                result.Code = rspObj.code;
                result.Message = rspObj.message;
                return result;
            }
            result.Message = "请求成功";
            result.Data = this.GetRspData<T>(rspObj);
            return result;
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rspResult"></param>
        /// <returns></returns>
        private T GetRspData<T>(JsonResult rspResult)
        {
            var reqType = typeof(T);
            if (!reqType.IsClass || reqType == typeof(string)) return default(T);
            var reqInstance = Activator.CreateInstance(reqType);

            var rspType = rspResult.GetType();
            foreach (var propertyInfo in reqType.GetProperties())
            {
                PropertyInfo rspProperty = null;
                switch (propertyInfo.Name)
                {
                    case "MerchantOrderId": // 商户订单号
                        rspProperty = rspType.GetProperty("merchant_order_id");
                        break;
                    case "TradeNumber": // 首付游交易号
                        rspProperty = rspType.GetProperty("trade_number");
                        break;
                    case "TradeStatus": // 订单状态
                        rspProperty = rspType.GetProperty("trade_status");
                        break;
                    case "BillUrl": // 首付游账单链接
                        rspProperty = rspType.GetProperty("bill_url");
                        break;
                }
                if (rspProperty == null) continue;
                propertyInfo.SetValue(reqInstance, rspProperty.GetValue(rspResult, null), null);
            }
            return (T) reqInstance;
        }

        private delegate TOutput HandleDelegate(TInput input);

        #region 报文内容处理方法,子类实现
        /// <summary>
        /// 报文内容处理方法,子类实现
        /// </summary>
        /// <param name="reqObject">接口接收到的报文</param>
        /// <returns>处理结果报文</returns>
        protected abstract TOutput DoDeal(TInput reqObject);
        #endregion

        /// <summary>
        /// 查检请求数据参数
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        protected abstract SfyCustomResult CheckReqParamters(Dictionary<string, object> reqParams);

        /// <summary>
        /// 检查请求报文头参数
        /// </summary>
        /// <returns></returns>
        protected SfyCustomResult CheckHeaderParamters()
        {
            var result = new SfyCustomResult()
            {
                Code = "10001"
            };
            
            // 接口Url
            if (string.IsNullOrEmpty(SfyConfig.ApiUrl))
            {
                result.Message = "请在Conifg配置调用接口Url.";
                return result;
            }
            // 商户号
            if (string.IsNullOrEmpty(SfyConfig.MerchantCode))
            {
                result.Message = "请在Conifg配置商户号.";
                return result;
            }
            // 字符编码
            if (SfyConfig.Charset == null)
            {
                result.Message = "请在Conifg配置字符编码.";
                return result;
            }
            // 版本号
            if (string.IsNullOrEmpty(SfyConfig.Version))
            {
                result.Message = "请在Conifg配置版本号.";
                return result;
            }
            // 支付Url
            if (string.IsNullOrEmpty(SfyConfig.PayUrl))
            {
                result.Message = "请在Conifg配置支付Url.";
                return result;
            }
            // 私钥
            if (string.IsNullOrEmpty(SfyConfig.PrivateKey))
            {
                result.Message = "请在Conifg配置私钥.";
                return result;
            }
            result.IsSuccess = true;
            return result;
        }
    }
}
