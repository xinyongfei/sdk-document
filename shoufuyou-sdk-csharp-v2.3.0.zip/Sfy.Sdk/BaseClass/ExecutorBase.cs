﻿using System;
using System.Net; 

namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TOutput"></typeparam>
    /// <typeparam name="TInput"></typeparam>
    internal abstract class ExecutorBase<TInput, TOutput>
    {
        #region 类成员
        /// <summary>
        /// 代理
        /// </summary>
        /// <param name="reqObject"></param>
        /// <returns></returns>
        private delegate SfyRspResult<TOutput> HandleDelegate(TInput reqObject, ReqType reqType);

        #endregion

        /// <summary>
        /// 所有接口调用入口，所有接口调用必须使用此方法以保证所有调用异常均被捕捉
        /// </summary>
        /// <param name="reqObject"> 输入参数</param>
        /// <param name="reqType">接口类型</param>
        /// <returns>输出参数</returns>
        public SfyRspResult<TOutput> Invoke(TInput reqObject, ReqType reqType)
        {
            var rspObject = default(SfyRspResult<TOutput>);
            var hd = new HandleDelegate(DoHandle);
             
            try
            {
                // 调用接口内容处理
                rspObject = hd(reqObject, reqType);
            }
            catch (WebException wex)
            {
                rspObject = this.GetDefaultResult("10010", string.Format("网络请求异常: {0}", wex.Message), reqType);
            }
            catch (Exception ex)
            {
                rspObject = this.GetDefaultResult(this.GetReqType(reqType), string.Format("异常：{0},堆栈：{1}", ex.Message, ex.StackTrace), reqType);
            }
            return rspObject;
        }

        #region 接口处理具体实现，各接口必须实现此方法

        /// <summary>
        /// 接口处理具体实现，各接口必须实现此方法
        /// </summary>
        /// <param name="reqObject"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        protected abstract SfyRspResult<TOutput> DoHandle(TInput reqObject, ReqType reqType);
        #endregion

        #region 发生异常时返回的默认应答

        /// <summary>
        /// 发生异常时返回的默认应答
        /// </summary>
        /// <param name="errorMsg"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        public abstract SfyRspResult<TOutput> GetDefaultResult(string errorCode, string errorMsg, ReqType reqType);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqType"></param>
        /// <returns></returns>
        private string GetReqType(ReqType reqType)
        {
            var errorCode = string.Empty;

            switch (reqType)
            {
                case ReqType.TradeCreate:
                    errorCode = "20030";
                    break;
                case ReqType.TradeLoan:
                    errorCode = "40005";
                    break;
                case ReqType.TradeQuery:
                    errorCode = "30006";
                    break;
                case ReqType.TradeRefund:
                    errorCode = "50010";
                    break;
            }
            return errorCode;
        }

        #endregion

        /// <summary>
        /// 接口调用日志
        /// </summary>
        /// <param name="reqObject"></param>
        /// <param name="rspObject"></param>
        public virtual void WriteLog(TInput reqObject, TOutput rspObject)
        {
            // 是否记录Log
            //new Task(() =>
            //{
            //    if (model.IsException)
            //    {
            //        LogHelper.Error(string.Format("TraceId：{0}\r\nErrorMsg：{1}\r\nElapsed：{2}\r\nreqObject：{3}\r\nrspObject：{4}", model.TraceId, model.ResultMsg, model.Elapsed, reqObject.ObjectToXML(), rspObject.ObjectToXML()));
            //        return;
            //    }
            //    LogHelper.Info(string.Format("TraceId：{0}\r\nIsSuccess：{1}\r\nElapsed：{2}\r\nreqObject：{3}\r\nrspObject：{4}", model.TraceId, model.IsSuccess, model.Elapsed, reqObject.ObjectToXML(), rspObject.ObjectToXML()));
            //}).Start();
        }
    }
}
