﻿using System;
using System.Collections.Generic;

namespace Sfy.Skd
{
    /// <summary>
    /// 首付游交易查询接口
    /// </summary>
    internal sealed class TradeQuerySync : RequestBase<string, string>
    {
        /// <summary>
        /// 商户请求首付游查询某一个订单的具体信息。
        /// </summary>
        /// <param name="reqObject"></param>
        /// <returns></returns>
        protected override string DoDeal(string reqObject)
        {
            throw new NotImplementedException();
        }

        #region 【查检请求数据参数】
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dicts"></param>
        /// <returns></returns>
        private CustomResult CheckReqParamters(Dictionary<string, object> dicts)
        {
            var result = new CustomResult()
            {
                Code = "30001"
            };

            if (dicts == null || dicts.Count <= 0)
            {
                result.Message = "请求的交易查询接口参数不能为空.";
                return result;
            }

            foreach (var dict in dicts)
            {
                switch (dict.Key.ToLower())
                {
                    case "merchant_order_id":
                        if (result.IsEmptyStr(dict.Value, "商户订单号")) return result;
                        break;
                    case "trade_number":
                        if (result.IsEmptyStr(dict.Value, "首付游交易号")) return result;
                        break;
                }
            }
            result.IsSuccess = true;
            return result;
        }
        #endregion
    }
}
