﻿using System;
using System.Collections.Generic;

namespace Sfy.Skd
{
    /// <summary>
    /// 首付游收单接口（网关模式）
    /// </summary>
    internal sealed class TradeCreateSync : RequestBase<string, string>
    {
        /// <summary>
        /// 商户请求首付游生成首付游交易单。
        /// </summary>
        /// <param name="reqObject"></param>
        /// <returns></returns>
        protected override string DoDeal(string reqObject)
        {
            throw new NotImplementedException();
        }

        #region 【查检请求数据参数】

        /// <summary>
        /// 
        /// </summary>
        private static readonly Dictionary<string, string> dicts = new Dictionary<string, string>()
        {
            {"merchant_order_id","商户订单号"}
        };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dicts"></param>
        /// <returns></returns>
        private CustomResult CheckReqParamters(Dictionary<string, object> dicts)
        {
            var result = new CustomResult()
            {
                Code = "20001"
            };

            if (dicts == null || dicts.Count <= 0)
            {
                result.Message = "请求的收单接口参数不能为空.";
                return result;
            }

            foreach (var dict in dicts)
            {
                switch (dict.Key.ToLower())
                {
                    case "merchant_order_id":
                        if (result.IsEmptyStr(dict.Value, "商户订单号")) return result;
                        break;
                    case "product_type":
                        if (result.IsEmptyStr(dict.Value, "产品类型")) return result;
                        break;
                    case "product_name":
                        if (result.IsEmptyStr(dict.Value, "产品名称")) return result;
                        break;
                    case "product_url":
                        if (result.IsEmptyStr(dict.Value, "产品 url")) return result;
                        break;
                    case "price":
                        if (result.IsEmptyInt(dict.Value, "订单总价")) return result;
                        break;
                    case "time_limit":
                        if (result.IsEmptyInt(dict.Value, "订单有效时长")) return result;
                        break;
                    case "tourist_number":
                        if (result.IsEmptyInt(dict.Value, "出行人数")) return result;
                        break;
                    case "departure":
                        if (result.IsEmptyStr(dict.Value, "出发城市")) return result;
                        break;
                    case "arrival":
                        if (result.IsEmptyStr(dict.Value, "目的地城市")) return result;
                        break;
                    case "departure_date":
                        if (result.IsEmptyStr(dict.Value, "出发日期")) return result;
                        break;
                    case "return_date":
                        if (result.IsEmptyStr(dict.Value, "返程日期")) return result;
                        break;
                    case "source_type":
                        if (result.IsEmptyStr(dict.Value, "订单来源类型")) return result;
                        break;
                    case "emergency_nam e":
                        if (result.IsEmptyStr(dict.Value, "目的地城市")) return result;
                        break;
                }
            }
            result.IsSuccess = true;
            return result;
        }
        #endregion
    }
}
