﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sfy.Sdk.Demo
{
    public partial class Demo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.GetReqJson(GetReqTradeCreateJosn());
            }
        }

        protected void btSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txtReqJson.Text))
            {
                this.lbErrorMsg.Text = "请输入请求报文.";
                return;
            }

            try
            {
                var serializer = new JavaScriptSerializer();

                var reqParams = serializer.Deserialize<Dictionary<string, object>>(this.txtReqJson.Text);

                object rspParams = null;

                switch (this.ddlReqType.SelectedValue)
                {
                    case "TradeCreate":

                        rspParams = SfyApi.TradeCreate<SfyTradeCreateResult>(reqParams);
                        break;
                    case "TradeLoan":

                        rspParams = SfyApi.TradeLoan<SfyTradeLoanResult>(reqParams);
                        break;
                    case "TradeQuery":

                        rspParams = SfyApi.TradeQuery<SfyTradeQueryResult>(reqParams);
                        break;
                    case "TradeRefund":

                        rspParams = SfyApi.TradeRefund<SfyTradeRefundResult>(reqParams);
                        break;
                }

                this.txtRspJson.Text = serializer.Serialize(rspParams);
            }
            catch (Exception ex)
            {
                this.lbErrorMsg.Text = ex.Message;
            }
        }

        [WebMethod]
        public static string ChangedSelectedIndex(string reqType)
        {
            try
            {
                Dictionary<string, object> reqParams = null;

                switch (reqType)
                {
                    case "TradeCreate":

                        reqParams = GetReqTradeCreateJosn();
                        break;
                    case "TradeLoan":

                        reqParams = GetReqTradeLoanJosn();
                        break;
                    case "TradeQuery":

                        reqParams = GetReqTradeQueryJosn();
                        break;
                    case "TradeRefund":

                        reqParams = GetReqTradeRefundJosn();
                        break;
                }
                var serializer = new JavaScriptSerializer();
                return serializer.Serialize(reqParams);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlReqType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Dictionary<string, object> reqParams = null;

                switch (this.ddlReqType.SelectedValue)
                {
                    case "TradeCreate":

                        reqParams = GetReqTradeCreateJosn();
                        break;
                    case "TradeLoan":

                        reqParams = GetReqTradeLoanJosn();
                        break;
                    case "TradeQuery":

                        reqParams = GetReqTradeQueryJosn();
                        break;
                    case "TradeRefund":

                        reqParams = GetReqTradeRefundJosn();
                        break;
                }

                this.GetReqJson(reqParams);
            }
            catch (Exception ex)
            {
                this.lbErrorMsg.Text = ex.Message;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        protected void GetReqJson(Dictionary<string, object> reqParams)
        {
            this.lbErrorMsg.Text = 
            this.txtRspJson.Text = string.Empty;

            var serializer = new JavaScriptSerializer();
            this.txtReqJson.Text = serializer.Serialize(reqParams).Replace("\",\"", "\",\n\"");
        }

        #region 【生成请求数据报文】

        /// <summary>
        /// Trade Create
        /// </summary>
        /// <returns></returns>
        private static Dictionary<string, object> GetReqTradeCreateJosn()
        {
            var reqParams = new Dictionary<string, object>
            {
                //商户订单号
                {"merchant_order_id","test12345"},
                //产品类型：free_tour（自由行），group_tour（跟团游），local_tour（当地游），flight（机票）
                {"product_type","free_tour"},
                //产品名称
                {"product_name","北京到东京自由行"},
                //产品详情地址
                {"product_url","https://m.shoufuyou.com/products/100136"},
                //产品id
                {"product_id","100136"},
                //产品总价，单位为分，800000=8000元
                {"order_amount","10000"},
                //订单有效时长（分钟）
                {"time_limit","60"},
                //出行成人数，1~2
                {"tourist_adult_number","2"},
                //出行小孩人数，1~2
                {"tourist_kid_number","1"},
                //出行婴儿人数，1~2
                {"tourist_baby_number","0"},
                //出发地
                {"departure","北京"},
                //目的地
                {"arrival","东京"},
                //出发日期，格式"YYYY-mm-dd"
                {"departure_date","2016-03-05"},
                //返程日期，格式"YYYY-mm-dd"
                {"return_date","2016-03-08"},
                //酒店等级
                {"hotel_class","4"},
                //订单来源类型：ios，android，pc，wap
                {"source_type","ios"},
                //额外参数:若使用该字段，则用户传非空值，收单接口原样返回
                //{"extra_param","测试数据"},
                //页面回调地址
                {"return_url","http://api.test.shoufuyou.com/after_pay_return.aspx"},
                //异步通知地址
                {"notify_url","http://api.test.shoufuyou.com/after_pay_notify.aspx"},
                {
                    "tourists",new List<object>()
                    {
                        new{name="王益",id_card_number="330281198803101756",mobile="13636364541",email="yywangyi@gmail.com"}
                    }
                }
            };

            return reqParams;
        }

        /// <summary>
        /// Trade Loan
        /// </summary>
        /// <returns></returns>
        private static Dictionary<string, object> GetReqTradeLoanJosn()
        {
            var reqParams = new Dictionary<string, object>
            {
                //商户订单id
                {"merchant_order_id","201603151602"},
                //首付游交易号
                {"trade_number","201603151605082296"},
                //异步通知地址
                {"notify_url","http://api.test.shoufuyou.com/after_loan_notify.aspx"},
            };

            return reqParams;
        }

        /// <summary>
        /// Trade Query
        /// </summary>
        /// <returns></returns>
        private static Dictionary<string, object> GetReqTradeQueryJosn()
        {
            var reqParams = new Dictionary<string, object>
            {
                //商户订单id
                {"merchant_order_id","98789651321536113129"},
                //首付游交易号
                {"trade_number","201603120830033968"}
            };

            return reqParams;
        }

        /// <summary>
        /// Trade Refund
        /// </summary>
        /// <returns></returns>
        private static Dictionary<string, object> GetReqTradeRefundJosn()
        {
            var reqParams = new Dictionary<string, object>
            {
                //商户订单号
                {"merchant_order_id","20260311232020365"},
                //首付游交易号
                {"trade_number","201603142112010953"},
                //退款金额，单位为分，240000=2400元
                {"refund_amount","240000"},
                //退款理由
                {"refund_reason","用户要求退款"},
                //异步通知地址
                {"notify_url","http://api.test.shoufuyou.com/after_refund_notify.aspx"}
            };

            return reqParams;
        }
        #endregion
    }
}