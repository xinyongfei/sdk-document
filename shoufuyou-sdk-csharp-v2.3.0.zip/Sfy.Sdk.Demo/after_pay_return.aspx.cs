﻿using System;

namespace Sfy.Sdk.Demo
{
    public partial class after_pay_return : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var result = SfyPay.ReturnVerify();

            if (result.TradeStatus == "PAY_SUCCESS")
	        {
                // 支付成功，此处执行支付成功业务逻辑
                Response.Write(string.Format("返回的结果码：{0}</br>", result.Code));
                Response.Write(string.Format("返回结果码对应的字符串：{0}</br>", result.Message));
                Response.Write(string.Format("订单状态：{0}</br>", result.TradeStatus));
                Response.Write(string.Format("商户订单号：{0}</br>", result.MerchantOrderId));
                Response.Write(string.Format("首付游交易号：{0}</br>", result.TradeNumber));
                Response.Write(string.Format("订单价格：{0}</br>", result.OrderAmount));
                Response.Write(string.Format("账单地址：{0}</br>", result.BillUrl));
                Response.Write(string.Format("额外参数：{0}</br>", result.ExtraParam));
            }
            else
            {
                Response.Write(string.Format("返回的结果码：{0}</br>", result.Code));
                Response.Write(string.Format("返回结果码对应的字符串：{0}</br>", result.Message));
                Response.Write(string.Format("订单状态：{0}</br>", result.TradeStatus));
                Response.Write(string.Format("商户订单号：{0}</br>", result.MerchantOrderId));
                Response.Write(string.Format("首付游交易号：{0}</br>", result.TradeNumber));
                Response.Write(string.Format("订单价格：{0}</br>", result.OrderAmount));
                Response.Write(string.Format("账单地址：{0}</br>", result.BillUrl));
                Response.Write(string.Format("额外参数：{0}</br>", result.ExtraParam));
            }
        }
    }
}