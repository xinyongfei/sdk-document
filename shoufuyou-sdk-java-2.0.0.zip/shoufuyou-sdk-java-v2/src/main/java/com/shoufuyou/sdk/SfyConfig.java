package com.shoufuyou.sdk;

public class SfyConfig {
    private String merchantCode;
    private String privateKey;
    private String payUrl;
    private String apiUrl;
    private String version;

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String value) {
        merchantCode = value;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String value) {
        privateKey = value;
    }

    public String getPayUrl() {
        return payUrl;
    }

    public void setPayUrl(String value) {
        payUrl = value;
    }

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String value) {
        apiUrl = value;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String value) {
        version = value;
    }
}
