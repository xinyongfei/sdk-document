package com.shoufuyou.sdk;

import java.util.concurrent.ConcurrentHashMap;

public final class TradeStatus {
    public static final TradeStatus WAIT_PAY;
    public static final TradeStatus PAY_SUCCESS;
    public static final TradeStatus PAY_FAILED;
    public static final TradeStatus WAIT_REFUND;
    public static final TradeStatus REFUND_FAILED;
    public static final TradeStatus REFUND_SUCCESS;
    public static final TradeStatus CANCELED;

    private static ConcurrentHashMap<String, TradeStatus> tradeStatuses = new ConcurrentHashMap<String, TradeStatus>();

    static {
        WAIT_PAY = new TradeStatus("WAIT_PAY");
        PAY_SUCCESS = new TradeStatus("PAY_SUCCESS");
        PAY_FAILED = new TradeStatus("PAY_FAILED");
        WAIT_REFUND = new TradeStatus("WAIT_REFUND");
        REFUND_FAILED = new TradeStatus("REFUND_FAILED");
        REFUND_SUCCESS = new TradeStatus("REFUND_SUCCESS");
        CANCELED = new TradeStatus("CANCELED");
    }

    private String name;

    private TradeStatus(final String name) {
        this.name = name;
        if (tradeStatuses.putIfAbsent(name, this) != null) {
            throw new IllegalStateException(
                "Trade status '" + name + "' has already been defined."
            );
        }
    }

    public static TradeStatus forName(final String name) {
        final TradeStatus result = tradeStatuses.get(name);
        if (result != null) {
            return result;
        }
        try {
            return new TradeStatus(name);
        } catch (IllegalStateException e) {
            return tradeStatuses.get(name);
        }
    }

    @Override
    public String toString() {
        return this.name;
    }
}
