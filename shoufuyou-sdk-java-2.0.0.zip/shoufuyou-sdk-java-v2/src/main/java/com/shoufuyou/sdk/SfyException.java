package com.shoufuyou.sdk;

public class SfyException extends RuntimeException {
    private static final long serialVersionUID = 927469644664611642L;
    private int code;
    private String merchantOrderId;

    public SfyException(String message) {
        super(message);
        this.code = 0;
    }

    public SfyException(String message, int code, String merchantOrderId) {
        super(message);
        this.code = code;
        this.merchantOrderId = merchantOrderId;
    }

    public int getCode() {
        return this.code;
    }

    public String getMerchantOrderId() {
        return this.merchantOrderId;
    }

    @Override
    public String toString() {
        return "[" + String.valueOf(code) + "]: " + this.getMessage();
    }
}
