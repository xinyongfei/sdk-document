package com.shoufuyou.sdk.demo;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shoufuyou.sdk.*;

//支付
@SuppressWarnings("serial")
public class TradeCreateServlet extends HttpServlet implements javax.servlet.Servlet{ 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        SfyClient client = SfyClientFactory.createSfyClient();
        PayRequest payRequest = new PayRequest();
        payRequest.setMerchantOrderId("5789651321512312");
        payRequest.setPeriods(12);
        payRequest.setProductId("1001215");
        payRequest.setProductName("北京到东京自由行");
        payRequest.setProductType("free_tour");
        payRequest.setProductUrl("https://m.shoufuyou.com/products/1001363");
        payRequest.setOrderAmount(10000);
        payRequest.setTimeLimit(1000);
        payRequest.setDeparture("北京");
        payRequest.setArrival("东京");
        payRequest.setDepartureDate("2016-03-05");
        payRequest.setReturnDate("2016-03-08");
        payRequest.setHotelClass(4);
        payRequest.setSourceType("wap");
        payRequest.setEmergencyName("丁力");
        payRequest.setEmergencyMobile("18817301130");
        payRequest.setEmergencyRelationship("朋友");
        payRequest.setReturnUrl("http://hostname:8080/shoufuyou-sdk-demo/after-pay-return");
        payRequest.setNotifyUrl("http://hostname:8080/shoufuyou-sdk-demo/after-pay-notify");
        PayRequestTourist tourist = new PayRequestTourist();
        tourist.setName("蓝俊");
        tourist.setNameSpelling("Lan Jun");
        tourist.setIdCardNumber("442000198808080358");
        tourist.setMobile("13480968877");
        tourist.setEmail("noreply@gmail.com");
        payRequest.addTourist(tourist);
        payRequest.setTouristAdultNumber(1);
        payRequest.setTouristKidNumber(0);
        payRequest.setTouristBabyNumber(0);
        response.getWriter().write(client.buildPayRequestHtml(payRequest));
    }
}
