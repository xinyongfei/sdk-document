<?php 
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'SfyApi.php';

//demo 订单查询接口
$arr = array(
    //商户订单号
    'merchant_order_id'     => '98789651321536113129',
    //首付游交易号
    'trade_number'          => '201603120830033968',
);
$api = new sfyApi();
$resultArray = $api->tradeQuery($arr);
var_dump($resultArray);exit;
?>