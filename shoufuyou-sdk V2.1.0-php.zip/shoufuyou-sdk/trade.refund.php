<?php
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'SfyApi.php';

//demo 授信接口
$arr = array(
    
);
$api = new SfyApi();
$resultArray = $api->refund($arr);
var_dump($resultArray);exit;
?>