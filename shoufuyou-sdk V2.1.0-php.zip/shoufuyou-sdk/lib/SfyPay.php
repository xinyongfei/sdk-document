<?php
require_once 'SfyUtil.php';
require_once 'SfyConfig.php';
/**
 * 网关收单类
 * @author Administrator
 *
 */

class SfyPay {
    public function buildRequestHtml(array $requestData) {
        $html = '<!DOCTYPE html><html><head><meta charset="utf-8"/></head><body onload="autosubmit()"><form method="post" action="' . SfyConfig::PAY_URL . '" id="payForm">';

        $formData = SfyUtil::buildFormData($requestData);
        foreach ($formData as $inputName => $inputValue) {
            $html .= '<input type="hidden" id="' . $inputName . '" name="' . $inputName . '" value="' . $inputValue . '">';
        }

        $html .= '</form><script>function autosubmit(){document.getElementById("payForm").submit();}</script></body></html>';
        return $html;
    }

    public function hasError() {
        return isset($_GET['error_code']) || isset($_GET['error_msg']);
    }

    public function getErrorMessage() {
        return ['error_code' => $_GET['error_code'], 'error_msg' => $_GET['error_msg']];
    }

    public function getReturnData() {
        return json_decode(SfyUtil::decrypt($_GET['biz_content'], SfyConfig::PRIVATE_KEY), true);
    }

    public function getNotifyData() {
        return json_decode(SfyUtil::decrypt($_POST['biz_content'], SfyConfig::PRIVATE_KEY), true);
    }

    public function returnVerify() {
        return SfyUtil::checkSign($_GET);
    }

    public function notifyVerify() {
        return SfyUtil::checkSign($_POST);
    }

    private function checkRequiredParamters(array $requiredParametersArray, array $data, $errorCode) {
        foreach ($requiredParametersArray as $requiredParameters) {
            if (!isset($data[$requiredParameters])) {
                return array('code' => $errorCode, 'message' => '缺少必填参数' . $requiredParameters);
            }
        }
        return true;
    }
}