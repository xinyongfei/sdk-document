<?php
require_once 'SfyUtil.php';
/**
 * API接口类
 * @author Administrator
 *
 */

class SfyApi {
    /**
    *
    *授信接口
    *
    *
    */
    public function trustQuery($data) {
        $method = 'trust.query';
        $requiredParametersArray = array(
            'cert_type',
            'cert_no',
            'name',
            'mobile',
            'email'
        );

        if (($checkResult = $this->checkRequiredParamters($requiredParametersArray, $data, '20001')) !== true) {
            return $checkResult;
        }

        return SfyUtil::submitData($data, $method);
    }


    /**
    *
    *请求首付游生成订单接口
    *
    *method:sfyapi.order.create
    */
    public function orderCreate($data) {
        $method = 'order.create';
        
        $requiredParametersArray = array(
            'cert_type',
            'cert_no',
            'name',
            'mobile',
            'email',
            'merchant_order_id',
            'product_name',
            'product_url',
            'user_departure_date',
            'order_amount',
            'order_down_payment'
        );

        if (($checkResult = $this->checkRequiredParamters($requiredParametersArray, $data, '30001')) !== true) {
            return $checkResult;
        }

        return SfyUtil::submitData($data, $method);
    }

    /**
    *
    *查询首付游订单接口
    *method:sfyapi.order.query
    */
    public function tradeQuery($data) {
        $method = 'trade.query';
        //检测必填参数
        $requiredParametersArray = array(
            'merchant_order_id',
            'trade_number',
        );

        if (($checkResult = $this->checkRequiredParamters($requiredParametersArray, $data, '40001')) !== true) {
            return $checkResult;
        }

        return SfyUtil::submitData($data, $method);
    }

    /**
    *
    *请求首付游放款接口，
    * method:trade.loan
    */
    public function tradeLoan($data) {
        $method = 'trade.loan';
        //检测必填参数
        $requiredParametersArray = array(
            'merchant_order_id',
            'trade_number',
            'notify_url'
        );

        if (($checkResult = $this->checkRequiredParamters($requiredParametersArray, $data, '50001')) !== true) {
            return $checkResult;
        }

        return SfyUtil::submitData($data, $method);
    }

    private function checkRequiredParamters(array $requiredParametersArray, array $data, $errorCode) {
        foreach ($requiredParametersArray as $requiredParameters) {
            if (!isset($data[$requiredParameters])) {
                return array('code' => $errorCode, 'message' => '缺少必填参数' . $requiredParameters);
            }
        }
        return true;
    }
}