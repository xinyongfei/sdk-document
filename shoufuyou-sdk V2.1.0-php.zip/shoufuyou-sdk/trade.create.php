<?php 
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'SfyPay.php';

//demo 请款接口
$payInfo = array(
    'merchant_order_id'     => '987896131112233121232',
    'product_id'            => '1001215',
    'product_name'          => '北京到东京自由行',
    'product_type'          => 'flight',
    'product_url'           => 'https://m.shoufuyou.com/products/1001363',
    'price'                 => 180000,
    'time_limit'            => 60,
    'tourist_number'        => 2,
    'departure'             => '北京',
    'arrival'               => '东京',
    'departure_date'        => '2016-03-05',
    'return_date'           => '2016-03-25',
    'hotel_class'           => 4,
    'source_type'           => 'wap',
    'emergency_name'        => '丁力',
    'emergency_mobile'      => '18817301130',
    'emergency_relationship'=> '朋友',
    'return_url'            => 'http://sdk.sfydev.com/after_pay_return.php',
    'notify_url'            => 'http://sdk.sfydev.com/after_pay_notify.php',
    //出行人信息
    'tourists'              => array(
        array(
            'name'          => '王益',
            'id_card_number'=> '330281198803101756',
            'mobile'        => '13636364541',
            'email'         => 'yywangyi@gmail.com'
        ),
        array(
            'name'          => '郭佳凤',
            'id_card_number'=> '320681198911086645',
            'mobile'        => '18721550656',
            'email'         => 'yywangyi@gmail.com'
        ),
    )
);
$sfyPay = new SfyPay();
$html = $sfyPay->buildRequestHtml($payInfo);
echo $html;
?>