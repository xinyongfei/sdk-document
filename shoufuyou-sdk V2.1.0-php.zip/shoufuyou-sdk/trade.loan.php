<?php 
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'SfyApi.php';

//demo 请款接口
$arr = array(
    //商户订单号
    'merchant_order_id'     => '98789651321536113129',
    //首付游交易号
    'trade_number'          => '201603120830033968',
    //请款成功后异步通知url
    'notify_url'            => 'http://sdk.sfydev.com/after_loan_notify.php'
);
$api = new SfyApi();
$resultArray = $api->tradeLoan($arr);
var_dump($resultArray);exit;
?>