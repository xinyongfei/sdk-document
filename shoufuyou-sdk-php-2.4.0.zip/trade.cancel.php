<?php
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'SfyApi.php';

//demo 退款接口
$arr = array(
    //商户订单号
    'merchant_order_id'     => '1473145339',
);
$api = new SfyApi();
$resultArray = $api->tradeCancel($arr);
echo json_encode($resultArray);exit;
?>
