package com.shoufuyou.sdk;

public class TradeRefundNotification {
    private String merchantOrderId;
    private String merchantRefundId;
    private int refundTotalAmount;
    private int refundAmount;

    public String getMerchantOrderId() {
        return merchantOrderId;
    }

    public void setMerchantOrderId(String merchantOrderId) {
        this.merchantOrderId = merchantOrderId;
    }

    public String getMerchantRefundId() {
        return merchantRefundId;
    }

    public void setMerchantRefundId(String merchantRefundId) {
        this.merchantRefundId = merchantRefundId;
    }

    public int getRefundTotalAmount() {
        return refundTotalAmount;
    }

    public void setRefundTotalAmount(int refundTotalAmount) {
        this.refundTotalAmount = refundTotalAmount;
    }

    public int getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(int refundAmount) {
        this.refundAmount = refundAmount;
    }
}
