package com.shoufuyou.sdk;

import java.util.*;

public class PayRequest {
    private String merchantOrderId;
    private int periods;
    private String productId;
    private String productName;
    private String productType;
    private String productUrl;
    private int orderAmount;
    private int timeLimit;
    private int touristAdultNumber;
    private int touristKidNumber;
    private int touristBabyNumber;
    private ArrayList<PayRequestTourist> tourists = new ArrayList<PayRequestTourist>();
    private String departure;
    private String arrival;
    private String departureDate;
    private String returnDate;
    private int hotelClass;
    private String sourceType;
    private String extraParam;
    private String returnUrl;
    private String notifyUrl;

    public void addTourist(PayRequestTourist tourist) {
        tourists.add(tourist);
    }

    public String getMerchantOrderId() {
        return merchantOrderId;
    }

    public void setMerchantOrderId(String merchantOrderId) {
        this.merchantOrderId = merchantOrderId;
    }

    public int getPeriods() {
        return periods;
    }

    public void setPeriods(int periods) {
        this.periods = periods;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductUrl() {
        return productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    public int getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
    }

    public int getTimeLimit() {
        return timeLimit;
    }

    public void setTimeLimit(int timeLimit) {
        this.timeLimit = timeLimit;
    }

    public int getTouristAdultNumber() {
        return touristAdultNumber;
    }

    public void setTouristAdultNumber(int touristAdultNumber) {
        this.touristAdultNumber = touristAdultNumber;
    }

    public int getTouristKidNumber() {
        return touristKidNumber;
    }

    public void setTouristKidNumber(int touristKidNumber) {
        this.touristKidNumber = touristKidNumber;
    }

    public int getTouristBabyNumber() {
        return touristBabyNumber;
    }

    public void setTouristBabyNumber(int touristBabyNumber) {
        this.touristBabyNumber = touristBabyNumber;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public int getHotelClass() {
        return hotelClass;
    }

    public void setHotelClass(int hotelClass) {
        this.hotelClass = hotelClass;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getExtraParam() {
        return extraParam;
    }

    public void setExtraParam(String extraParam) {
        this.extraParam = extraParam;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public ArrayList<PayRequestTourist> getTourists() {
        return tourists;
    }
}
