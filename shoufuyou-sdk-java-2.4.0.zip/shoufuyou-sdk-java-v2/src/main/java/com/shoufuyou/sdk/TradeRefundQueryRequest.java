package com.shoufuyou.sdk;

public class TradeRefundQueryRequest {
    private String merchantRefundId;

    public String getMerchantRefundId() {
        return merchantRefundId;
    }

    public void setMerchantRefundId(String merchantRefundId) {
        this.merchantRefundId = merchantRefundId;
    }
}