package com.shoufuyou.sdk;

public class TradeStatementDownloadurlQueryRequest {
    private String statementDate;

    public String getStatementDate() {
        return statementDate;
    }

    public void setStatementDate(String statementDate) {
        this.statementDate = statementDate;
    }
}