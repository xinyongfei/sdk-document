package com.shoufuyou.sdk;

public class TradeRefundResponse extends TradeResponse {
    private int refundAmount;
    private int refundTotalAmount;
    private String merchantRefundId;

    public int getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(int refundAmount) {
        this.refundAmount = refundAmount;
    }

    public int getRefundTotalAmount() {
        return refundTotalAmount;
    }

    public void setRefundTotalAmount(int refundTotalAmount) {
        this.refundTotalAmount = refundTotalAmount;
    }

    public String getMerchantRefundId() {
        return merchantRefundId;
    }

    public void setMerchantRefundId(String merchantRefundId) {
        this.merchantRefundId = merchantRefundId;
    }
}
