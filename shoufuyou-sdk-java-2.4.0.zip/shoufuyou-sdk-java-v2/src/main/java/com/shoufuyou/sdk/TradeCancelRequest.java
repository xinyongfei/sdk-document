package com.shoufuyou.sdk;

public class TradeCancelRequest extends TradeRequest {
    
}