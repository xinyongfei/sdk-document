package com.shoufuyou.sdk;

public class TradeStatementDownloadurlQueryResponse {
    private String statementDownloadUrl;

    public String getStatementDownloadUrl() {
        return statementDownloadUrl;
    }

    public void setStatementDownloadUrl(String statementDownloadUrl) {
        this.statementDownloadUrl = statementDownloadUrl;
    }
}
