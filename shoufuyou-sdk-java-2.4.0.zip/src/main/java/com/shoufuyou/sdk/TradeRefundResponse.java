package com.shoufuyou.sdk;

public class TradeRefundResponse {
    private int refundAmount;
    private int refundTotalAmount;
    private String merchantRefundId;
    private String merchantOrderId;

    public int getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(int refundAmount) {
        this.refundAmount = refundAmount;
    }

    public int getRefundTotalAmount() {
        return refundTotalAmount;
    }

    public void setRefundTotalAmount(int refundTotalAmount) {
        this.refundTotalAmount = refundTotalAmount;
    }

    public String getMerchantRefundId() {
        return merchantRefundId;
    }

    public void setMerchantRefundId(String merchantRefundId) {
        this.merchantRefundId = merchantRefundId;
    }

    public String getMerchantOrderId() {
        return merchantOrderId;
    }

    public void setMerchantOrderId(String merchantOrderId) {
        this.merchantOrderId = merchantOrderId;
    }
}
