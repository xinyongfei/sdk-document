package com.shoufuyou.sdk;

public class TradeRateQueryResponse {
    private double installmentRate3;
    private double installmentRate6;
    private double installmentRate12;
    private double installmentDiscount;

    public double getInstallmentRate3() {
        return installmentRate3;
    }

    public void setInstallmentRate3(double installmentRate3) {
        this.installmentRate3 = installmentRate3;
    }

    public double getInstallmentRate6() {
        return installmentRate6;
    }

    public void setInstallmentRate6(double installmentRate6) {
        this.installmentRate6 = installmentRate6;
    }

    public double getInstallmentRate12() {
        return installmentRate12;
    }

    public void setInstallmentRate12(double installmentRate12) {
        this.installmentRate12 = installmentRate12;
    }

    public double getInstallmentDiscount() {
        return installmentDiscount;
    }

    public void setInstallmentDiscount(double installmentDiscount) {
        this.installmentDiscount = installmentDiscount;
    }
}
