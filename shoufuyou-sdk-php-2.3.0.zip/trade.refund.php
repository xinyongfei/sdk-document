<?php
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'SfyApi.php';

//demo 退款接口
$arr = array(
    //商户订单号
    'merchant_order_id'     => '201604250943',
    //首付游交易号
    'trade_number'          => '201604251210063828',
    //退款金额
    'refund_amount'         => '11',
    //退款理由
    'refund_reason'         => '用户要求退款',
    //退款成功后异步通知url
    'notify_url'            => 'https://m.shoufuyou.com/pay/after_refund_notify'
);
$api = new SfyApi();
$resultArray = $api->tradeRefund($arr);
echo json_encode($resultArray);exit;
?>
