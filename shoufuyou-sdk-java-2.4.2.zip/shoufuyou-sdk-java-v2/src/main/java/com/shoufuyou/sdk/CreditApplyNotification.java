package com.shoufuyou.sdk;

public class CreditApplyNotification {
    private String applyId;
    private String status;
    private String creditLineAmount;
    private String extraParam;

    public String getCreditLineAmount() {
        return creditLineAmount;
    }

    public void setCreditLineAmount(String creditLineAmount) {
        this.creditLineAmount = creditLineAmount;
    }

    public String getExtraParam() {
        return extraParam;
    }

    public void setExtraParam(String extraParam) {
        this.extraParam = extraParam;
    }

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
