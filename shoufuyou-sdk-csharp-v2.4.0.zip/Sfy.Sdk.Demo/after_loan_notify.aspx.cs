﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sfy.Sdk.Demo
{
    public partial class after_loan_notify : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var result = SfyPay.NotifyVerify();

            if (result.TradeStatus == "LOAN_SUCCESS")
            {
                // 请款成功，此处执行请款请求成功业务逻辑

            }
            else
            {
                // 请款失败，此处执行请款失败业务逻辑

            }
            Response.Write("SUCCESS");
        }
    }
}