﻿
namespace Sfy.Sdk
{
    internal class SfyErrorInfo
    {
    }
}
