﻿
namespace Sfy.Sdk
{
    public class SfyNotifyResult
    {
        /// <summary>
        /// 
        /// </summary>
        //public bool IsSuccess { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string Code { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string MerchantOrderId { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string TradeStatus { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string TradeNumber { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string Message { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string OrderAmount { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string BillUrl { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string ExtraParam { set; get; }
    }

    /// <summary>
    /// 
    /// </summary>
    internal class SfyNotifyRspResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string code { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string message { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string merchant_order_id { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string trade_status { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string trade_number { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string order_amount { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string bill_url { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string extra_param { set; get; }
    }
}
