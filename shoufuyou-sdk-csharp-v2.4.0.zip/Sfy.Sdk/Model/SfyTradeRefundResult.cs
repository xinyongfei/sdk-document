﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sfy.Sdk
{
    public class SfyTradeRefundResult
    {
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string MerchantOrderId { get; set; }

        /// <summary>
        /// 商户退款流水号
        /// </summary>
        public string MerchantRefundId { get; set; }

        /// <summary>
        /// 退款金额
        /// </summary>
        public string RefundAmount { get; set; }

        /// <summary>
        /// 已退总金额
        /// </summary>
        public string RefundTotalAmount { get; set; }
    }
}
