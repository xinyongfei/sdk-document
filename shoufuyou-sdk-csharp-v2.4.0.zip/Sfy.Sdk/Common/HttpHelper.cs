﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web;
using Newtonsoft.Json;

namespace Sfy.Sdk
{
    /// <summary>
    /// 请求Http
    /// </summary>
    internal sealed class HttpHelper
    {
        /// <summary>
        /// 静态构造函数
        /// </summary>
        static HttpHelper()
        {
            // 设置最大并发连接数
            ServicePointManager.DefaultConnectionLimit = 200;
        }

        #region Post请求数据

        /// <summary>
        /// 发出请求报文
        /// </summary>
        /// <param name="reqContent"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        public static RspResult Post(string reqContent, ReqType reqType)
        {
            var reqParams = CreateReqParamters(reqContent, reqType);

            var postData = string.Empty;

            foreach (var reqParam in reqParams)
            {
                postData += string.Format("{0}={1}&", HttpUtility.UrlEncode(reqParam.Key), HttpUtility.UrlEncode(reqParam.Value.ToString()));
            }
            var jsonStr = Post(SfyConfig.ApiUrl, postData.TrimEnd('&'));
            //var jsonStr = Post(SfyConfig.ApiUrl, JavaScriptConvert.SerializeObject(reqParams));

            if (jsonStr == null) return null;

            return JavaScriptConvert.Deserialize<RspResult>(jsonStr);
        }

        /// <summary>
        /// 发出请求报文
        /// </summary>
        /// <param name="reqContent"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        public static bool SubmitForm(string reqContent, ReqType reqType, string sourceType)
        {
            var reqParams = CreateReqParamters(reqContent, reqType);

            var postData = SfyUtil.BuildRequest(reqParams, sourceType);
            var httpContext = HttpContext.Current;
            if (httpContext != null)
            {
                httpContext.Response.Write(postData);
                //httpContext.Response.End();
            }
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqContent"></param>
        /// <param name="reqType"></param>
        public static Dictionary<string, object> CreateReqParamters(string reqContent, ReqType reqType)
        {
            var reqParams = new Dictionary<string, object>();

            // 业务参数
            reqParams.Add("biz_content", reqContent);
            // 字符编码
            reqParams.Add("charset", SfyConfig.Charset.WebName);
            // 商户号
            reqParams.Add("merchant_code", SfyConfig.MerchantCode);

            var methodType = string.Empty;
            switch (reqType)
            {
                case ReqType.TradeCreate:
                    methodType = "trade.create";
                    break;
                case ReqType.TradeLoan:
                    methodType = "trade.loan";
                    break;
                case ReqType.TradeQuery:
                    methodType = "trade.query";
                    break;
                case ReqType.TradeRefund:
                    methodType = "trade.refund";
                    break;
                case ReqType.TradeRefundQuery:
                    methodType = "trade.refund.query";
                    break;
            }
            // 接口名称
            reqParams.Add("method", methodType);
            // 时间戳
            var timeSpan = new TimeSpan(DateTime.Now.Ticks);
            reqParams.Add("timestamp", (long)timeSpan.TotalSeconds);
            // 版本号
            reqParams.Add("version", SfyConfig.Version);
            // 签名
            reqParams.Add("sign", SfyUtil.Sign(reqParams));

            return reqParams;
        }

        /// <summary>
        /// 发出请求报文
        /// </summary>
        /// <param name="resUrl">目标服务的接口地址</param>
        /// <param name="postData">请求报文</param>
        /// <returns></returns>
        public static string Post(string resUrl, string postData)
        {
            return Post(resUrl, postData, string.Empty, null);
        }

        /// <summary>
        /// 发出请求报文
        /// </summary>
        /// <param name="resUrl">目标服务的接口地址</param>
        /// <param name="contentType">请求报文类型</param>
        /// <param name="header">请求报文头</param>
        /// <param name="postData">请求报文</param>
        /// <returns></returns>
        private static string Post(string resUrl, string postData, string contentType, NameValueCollection header = null)
        {
            if (string.IsNullOrEmpty(contentType))
            {
                contentType = "application/x-www-form-urlencoded";
            }
            // 请求编码、应答编码
            var reqCoding = SfyConfig.Charset;
            var rspCoding = reqCoding;
            // 创建请求
            //var req = WebRequest.CreateHttp(resUrl);
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(CheckValidationResult);  

            var req = WebRequest.Create(resUrl);
            req.Method = "POST";				// Post method
            req.Timeout = SfyConfig.Timeout;    // 超时时间
            //req.ReadWriteTimeout = 5000;
            req.ContentType = contentType;		// content type

            // 设置请求头
            SetHeader(req, header);

            var bytes = reqCoding.GetBytes(postData);
            var inputStream = req.GetRequestStream();
            inputStream.Write(bytes, 0, bytes.Length);
            inputStream.Close();

            // 获取响应流
            var rsp = req.GetResponse();
            req.GetRequestStream().Close();

            string responseMsg;
            // 读取响应流
            using (var sr = new StreamReader(rsp.GetResponseStream(), rspCoding))
            {
                responseMsg = sr.ReadToEnd();
            }
            var responseStream = rsp.GetResponseStream();
            if (responseStream != null) responseStream.Close();

            return responseMsg;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="certificate"></param>
        /// <param name="chain"></param>
        /// <param name="errors"></param>
        /// <returns></returns>
        private static bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)  
        {  
            return true; //总是接受     
        }  

        #endregion

        /// <summary>
        /// 设置请求头
        /// </summary>
        /// <param name="httpGet"></param>
        /// <param name="header"></param>
        private static void SetHeader(WebRequest httpGet, NameValueCollection header)
        {
            if (header == null || header.Count == 0) return;
            foreach (var key in header.AllKeys)
            {
                httpGet.Headers.Add(key, header[key]);
            }
        }
    }
}
