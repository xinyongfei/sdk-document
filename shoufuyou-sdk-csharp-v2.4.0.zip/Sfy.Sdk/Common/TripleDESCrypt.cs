﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    internal class TripleDESCrypt
    {
        /// <summary>
        /// 加密字符串
        /// </summary>
        /// <param name="encryptStr"></param>
        /// <returns></returns>
        public static string Encrypt(string encryptStr)
        {
            if (string.IsNullOrEmpty(encryptStr)) return string.Empty;
            var encoding = SfyConfig.Charset;

            using (SymmetricAlgorithm algorithm = new TripleDESCryptoServiceProvider())
            {
                algorithm.Key = encoding.GetBytes(SfyConfig.PrivateKey);
                //algorithm.IV = Convert.FromBase64String(customIV);

                algorithm.Mode = CipherMode.ECB;
                algorithm.Padding = PaddingMode.PKCS7;

                var transform = algorithm.CreateEncryptor();

                var bytes = encoding.GetBytes(encryptStr);
                using (var memoryStream = new MemoryStream())
                {
                    using (var cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(bytes, 0, bytes.Length);
                        cryptoStream.FlushFinalBlock();

                        return Convert.ToBase64String(memoryStream.ToArray());
                    }
                }
            }
        }

        /// <summary>
        /// 解密字符串
        /// </summary>
        /// <param name="decryptStr"></param>
        /// <returns></returns>
        public static string Decrypt(string decryptStr)
        {
            if (string.IsNullOrEmpty(decryptStr)) return string.Empty;
            var encoding = SfyConfig.Charset;
            using (SymmetricAlgorithm algorithm = new TripleDESCryptoServiceProvider())
            {
                algorithm.Key = encoding.GetBytes(SfyConfig.PrivateKey);
                //algorithm.IV = Convert.FromBase64String(customIV);

                algorithm.Mode = CipherMode.ECB;
                algorithm.Padding = PaddingMode.PKCS7;

                using (var transform = algorithm.CreateDecryptor(algorithm.Key, algorithm.IV))
                {
                    var bytes = Convert.FromBase64String(decryptStr);
                    using (var memoryStream = new MemoryStream(bytes))
                    {
                        using (var cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read))
                        {
                            using (var reader = new StreamReader(cryptoStream, encoding))
                            {
                                return reader.ReadToEnd();
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 签名，连接biz_content， charset， merchant_code， method， timestamp， version，$private_key， 然后进行SHA256加密，不可逆转
        /// </summary>
        /// <param name="str">string str:被加密的字符串</param>
        /// <returns>返回加密后的字符串</returns>
        public static string Sign(string str)
        {
            using (var sha = new SHA256Managed())
            {
                var byteHash = sha.ComputeHash(Encoding.UTF8.GetBytes(str + SfyConfig.PrivateKey));

                return BitConverter.ToString(byteHash).Replace("-", "").ToLower();
            }
        }
    }
}
