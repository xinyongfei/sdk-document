﻿using System;
using System.Configuration;
using System.Text;

namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    internal sealed class SfyConfig
    {
        /// <summary>
        /// 编码格式
        /// </summary>
        public static Encoding Charset
        {
            get
            {
                var charset = ConfigurationManager.AppSettings["CHARSET"];
                if (string.IsNullOrEmpty(charset))
                {
                    charset = "UTF-8";
                }
                try
                {
                    return Encoding.GetEncoding(charset);
                }
                catch (Exception ex)
                {
                    // ignored
                }
                return Encoding.UTF8;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static string CaCertPath
        {
            get { return ConfigurationManager.AppSettings["CA_CERT_PATH"]; }
        }
        
        /// <summary>
        /// 接口Url
        /// </summary>
        public static string ApiUrl
        {
            get { return ConfigurationManager.AppSettings["API_URL"]; }
        }

        /// <summary>
        /// 商户号
        /// </summary>
        public static string MerchantCode
        {
            get { return ConfigurationManager.AppSettings["MERCHANT_CODE"]; }
        }

        /// <summary>
        /// 版本号
        /// </summary>
        public static string Version
        {
            get { return ConfigurationManager.AppSettings["VERSION"] ?? "1.0"; }
        }

        /// <summary>
        /// 私钥
        /// </summary>
        public static string PrivateKey
        {
            get { return ConfigurationManager.AppSettings["PRIVATE_KEY"]; }
        }

        /// <summary>
        /// PC支付Url
        /// </summary>
        public static string PayUrl
        {
            get { return ConfigurationManager.AppSettings["PAY_URL"]; }
        }

        /// <summary>
        /// MOBILE支付Url
        /// </summary>
        public static string PayMobileUrl
        {
            get { return ConfigurationManager.AppSettings["PAY_MOBILE_URL"]; }
        }

        /// <summary>
        /// 设置请求超时之前的时间长度（以毫秒为单位）
        /// </summary>
        public static int Timeout
        {
            get 
            {
                var timeout = 0;
                int.TryParse(ConfigurationManager.AppSettings["SFY_TIMEOUT"], out timeout);
                return timeout > 0 ? timeout : 3000;
            }
        }
    }
}
