﻿using System;
using System.Collections.Generic;

namespace Sfy.Skd
{
    /// <summary>
    /// 首付游退款请求接口
    /// </summary>
    internal sealed class TradeRefundSync : RequestBase<string, string>
    {
        /// <summary>
        /// 商户请求首付游给某个订单退款
        /// </summary>
        /// <param name="reqObject"></param>
        /// <returns></returns>
        protected override string DoDeal(string reqObject)
        {
            throw new NotImplementedException();
        }

        #region 【查检请求数据参数】
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dicts"></param>
        /// <returns></returns>
        private CustomResult CheckReqParamters(Dictionary<string, object> dicts)
        {
            var result = new CustomResult()
            {
                Code = "50001"
            };

            if (dicts == null || dicts.Count<=0)
            {
                result.Message = "请求的退款请求接口参数不能为空.";
                return result;
            }

            foreach (var dict in dicts)
            {
                switch (dict.Key.ToLower())
                {
                    case "merchant_order_id":
                        if (result.IsEmptyStr(dict.Value, "商户订单号")) return result;
                        break;
                    case "trade_number":
                        if (result.IsEmptyStr(dict.Value, "首付游交易号")) return result;
                        break;
                    case "refund_amount":
                        if (result.IsEmptyInt(dict.Value, "退款金额")) return result;
                        break;
                    case "refund_reason":
                        if (result.IsEmptyStr(dict.Value, "退款理由")) return result;
                        break;
                    case "notify_url":
                        if (result.IsEmptyStr(dict.Value, "通知地址")) return result;
                        break;
                }
            }
            result.IsSuccess = true;
            return result;
        }
        #endregion
    }
}
