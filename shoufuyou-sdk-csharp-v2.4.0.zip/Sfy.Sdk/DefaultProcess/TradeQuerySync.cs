﻿using System;
using System.Collections.Generic;

namespace Sfy.Sdk
{
    /// <summary>
    /// 首付游交易查询接口
    /// </summary>
    internal sealed class TradeQuerySync : RequestBase<string, string>
    {
        /// <summary>
        /// 商户请求首付游查询某一个订单的具体信息。
        /// </summary>
        /// <param name="reqContent"></param>
        /// <returns></returns>
        protected override string DoDeal(string reqContent)
        {
            throw new NotImplementedException();
        }

        #region 【查检请求数据参数】

        /// <summary>
        /// 
        /// </summary>
        private static readonly Dictionary<string, string> Dicts = new Dictionary<string, string>()
        {
            {"merchant_order_id","商户订单号"},
            {"trade_number","首付游交易号"}
        };

        /// <summary>
        /// 查检请求数据参数
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        protected override SfyCustomResult CheckReqParamters(Dictionary<string, object> reqParams)
        {
            var header = this.CheckHeaderParamters();
            if (!header.IsSuccess) return header;

            var result = new SfyCustomResult()
            {
                Code = "30001"
            };

            if (reqParams == null || reqParams.Count <= 0)
            {
                result.Message = "请求的交易查询接口参数不能为空.";
                return result;
            }

            foreach (var dict in Dicts)
            {
                if (SfyUtil.IsEmptyStr(result, reqParams, dict))
                {
                    switch (dict.Key)
                    {
                        case "merchant_order_id": // 商户订单号
                            result.Code = "30002";
                            break;
                        case "trade_number": // 首付游交易号
                            result.Code = "30003";
                            break;
                    }
                    return result;
                }
            }
            result.IsSuccess = true;
            return result;
        }
        #endregion
    }
}
