﻿
namespace Sfy.Sdk
{
    internal enum RequestType
    {
        /// <summary>
        /// 
        /// </summary>
        Post,
        /// <summary>
        /// 
        /// </summary>
        Get
    }
}
