﻿
namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    internal enum ReqType
    {
        /// <summary>
        /// 
        /// </summary>
        None,
        /// <summary>
        /// 首付游收单接口（网关模式）
        /// </summary>
        TradeCreate,
        /// <summary>
        /// 首付游放款请求接口
        /// </summary>
        TradeLoan,
        /// <summary>
        /// 首付游交易查询接口
        /// </summary>
        TradeQuery,
        /// <summary>
        /// 首付游退款请求接口
        /// </summary>
        TradeRefund,
        /// <summary>
        /// 首付游退款查询请求接口
        /// </summary>
        TradeRefundQuery
    }
}
