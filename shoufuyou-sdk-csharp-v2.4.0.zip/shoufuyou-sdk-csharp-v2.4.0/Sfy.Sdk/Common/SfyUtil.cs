﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using Newtonsoft.Json;

namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    internal static class SfyUtil
    {
        /// <summary>
        /// 
        /// </summary>
        internal static string FormatStr = "缺少必填参数：{0}.";

        /// <summary>
        /// 数据加密，3DESEncrypt->FromBase64->UrlEncode
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        public static string Encrypt(Dictionary<string, object> reqParams)
        {
            var jsonStr = JavaScriptConvert.SerializeObject(reqParams);

            return HttpUtility.UrlEncode(TripleDESCrypt.Encrypt(jsonStr));
        }

        /// <summary>
        /// 数据解密，UrlEncode->FromBase64->3DESEncrypt
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        public static string Decrypt(string reqParams)
        {
            return TripleDESCrypt.Decrypt(HttpUtility.UrlDecode(reqParams));
        }

        /// <summary>
        /// 数据签名
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        public static string Sign(Dictionary<string, object> reqParams)
        {
            if (reqParams == null || reqParams.Count <= 0) return string.Empty;
            var signStr = string.Empty;
            foreach (var reqParam in reqParams)
            {
                signStr += reqParam.Value.ToString();
            }
            return TripleDESCrypt.Sign(signStr);
        }

        /// <summary>
        /// 生成Form请求数据包
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        public static string BuildRequest(Dictionary<string, object> reqParams, string sourceType) 
        {
            var sdkUrl = SfyConfig.PayUrl;

            switch (sourceType.ToLower()) 
            {
                case "android" :
                case "ios" :
                case "wap" :
                    sdkUrl = SfyConfig.PayMobileUrl;
                    break;
                case "pc" :
                    sdkUrl = SfyConfig.PayUrl;
                    break;
            }

            var payFormHtml = string.Format("<!DOCTYPE html><html><head><meta charset='utf-8'/></head><body onload='autosubmit()'><form method='post' action='{0}' id='payForm'>", sdkUrl);

            foreach (var reqParam in reqParams)
            {
                payFormHtml += string.Format("<input type='hidden' id='{0}' name='{0}' value='{1}'>", reqParam.Key, reqParam.Value.ToString());
            }
            
            payFormHtml+= "</form><script>function autosubmit(){document.getElementById('payForm').submit();}</script></body></html>";

            return payFormHtml;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rspResult"></param>
        /// <returns></returns>
        public static bool CheckSign(RspResult rspResult)
        {
            if (rspResult == null) return false;
            var signStr = rspResult.biz_content;
            signStr += rspResult.charset;
            signStr += rspResult.merchant_code;
            signStr += rspResult.method;
            signStr += rspResult.timestamp;
            signStr += rspResult.version;

            return TripleDESCrypt.Sign(signStr) == rspResult.sign;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static SfyNotifyResult Verify()
        {
            var result = new SfyNotifyResult();
            try
            {
                var httpContext = HttpContext.Current;
                if (httpContext == null)
                {
                    result.Message = "当前 HTTP 请求的 HttpContext 对象无效.";
                    return result;
                }

                string code = string.Empty, message = string.Empty;
                RspResult rspResult = null;
                var request = httpContext.Request;
                
                switch (request.RequestType.ToLower())
                {
                    //case RequestType.Post:
                    case "post":

                        var jsonStr = string.Empty;

                        #region 【方法一】
                        
                        using (var reader = new StreamReader(request.InputStream))
                        {
                            jsonStr = reader.ReadToEnd();
                        }
                        if (!string.IsNullOrEmpty(jsonStr))
                        {
                            var reqParams = HttpUtility.ParseQueryString(jsonStr, SfyConfig.Charset);
                            rspResult = new RspResult();

                            foreach (var keyName in reqParams.AllKeys)
                            {
                                switch (keyName.ToLower())
                                {
                                    case "biz_content":
                                        rspResult.biz_content = reqParams.Get(keyName);
                                        break;
                                    case "charset":
                                        rspResult.charset = reqParams.Get(keyName);
                                        break;
                                    case "merchant_code":
                                        rspResult.merchant_code = reqParams.Get(keyName);
                                        break;
                                    case "method":
                                        rspResult.method = reqParams.Get(keyName);
                                        break;
                                    case "timestamp":
                                        rspResult.timestamp = reqParams.Get(keyName);
                                        break;
                                    case "version":
                                        rspResult.version = reqParams.Get(keyName);
                                        break;
                                    case "sign":
                                        rspResult.sign = reqParams.Get(keyName);
                                        break;
                                }
                            }
                        }

                        #endregion

                        #region 【方法二】
                        //var inputByte = request.BinaryRead(request.TotalBytes);
                        //if (inputByte.Length <= 0)
                        //{
                        //    result.ResultMsg = "暂无收到对应的数据请求包.";
                        //    return result;
                        //}
                        //jsonStr = SfyConfig.Charset.GetString(inputByte);
                        #endregion

                        //rspResult = JavaScriptConvert.Deserialize<RspResult>(jsonStr);

                        #region 【方法三】

                        if (rspResult == null || string.IsNullOrEmpty(rspResult.biz_content))
                        {
                            rspResult = new RspResult()
                            {
                                biz_content = request.Form["biz_content"],
                                charset = request.Form["charset"],
                                merchant_code = request.Form["merchant_code"],
                                method = request.Form["method"],
                                timestamp = request.Form["timestamp"],
                                version = request.Form["version"],
                                sign = request.Form["sign"]
                            };
                        }
                        
                        #endregion

                        break;
                    case "get":

                        rspResult = new RspResult()
                        {
                            biz_content = request.QueryString["biz_content"],
                            charset = request.QueryString["charset"],
                            merchant_code = request.QueryString["merchant_code"],
                            method = request.QueryString["method"],
                            timestamp = request.QueryString["timestamp"],
                            version = request.QueryString["version"],
                            sign = request.QueryString["sign"]
                        };
                        break;
                    default:
                        result.Message = string.Format("当前客户端使用的 HTTP 数据传输方式为：{0}.", request.RequestType);
                        return result;
                }

                if (!CheckSign(rspResult))
                {
                    result.Message = "签名错误.";
                    return result;
                }
                var bizContent = Decrypt(rspResult.biz_content);
                var rspObj = JavaScriptConvert.Deserialize<SfyNotifyRspResult>(bizContent);
                if (rspObj == null)
                {
                    result.Message = "请求的数据报文体为空.";
                    return result;
                }
                result.Code = rspObj.code;
                result.Message = rspObj.message;
                if (rspObj.code != "10000")
                {
                    result.Message = string.Format("{0}({1}).", rspObj.message, rspObj.code);
                    return result;
                }

                //result.IsSuccess = rspObj.trade_status.Equals("PAY_SUCCESS", StringComparison.OrdinalIgnoreCase);
                result.TradeStatus = rspObj.trade_status;
                result.MerchantOrderId = rspObj.merchant_order_id;
                result.TradeNumber = rspObj.trade_number;
                result.OrderAmount = rspObj.order_amount;
                result.BillUrl = rspObj.bill_url;
                result.ExtraParam = rspObj.extra_param;
            }
            catch (Exception ex)
            {
                //result.IsSuccess = false;
                result.Message = string.Format("异常：{0},堆栈：{1}", ex.Message, ex.StackTrace);
            }
            return result;
        }

        /// <summary>
        /// 检查字符是否为空
        /// </summary>
        /// <param name="result"></param>
        /// <param name="reqParams"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool IsEmptyStr(SfyCustomResult result, Dictionary<string, object> reqParams, KeyValuePair<string, string> key)
        {
            result.IsSuccess = false;
            result.Message = string.Empty;
            if (!reqParams.ContainsKey(key.Key))
            {
                result.Message = string.Format(FormatStr, key.Value);
                return true;
            }
            var value = reqParams[key.Key];

            if (value == null)
            {
                result.Message = string.Format(FormatStr, key.Value);
                return true;
            }
            if (string.IsNullOrEmpty(value.ToString()))
            {
                result.Message = string.Format(FormatStr, key.Value);
                return true;
            }
            result.IsSuccess = true;
            return false;
        }

        /// <summary>
        /// 检查Int是否为空
        /// </summary>
        /// <param name="result"></param>
        /// <param name="value"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static bool IsEmptyInt(SfyCustomResult result, Dictionary<string, object> reqParams, KeyValuePair<string, string> key)
        {
            result.IsSuccess = false;
            result.Message = string.Empty;

            if (!reqParams.ContainsKey(key.Key))
            {
                result.Message = string.Format(FormatStr, key.Value);
                return true;
            }
            var value = reqParams[key.Key];

            if (value == null)
            {
                result.Message = string.Format(FormatStr, key.Value);
                return true;
            }

            long intValue = 0;
            long.TryParse(value.ToString(), out intValue);
            
            result.IsSuccess = intValue > 0;
            if (result.IsSuccess) return false;

            result.Message = string.Format(FormatStr, key.Value);
            return true;
        }
    }
}
