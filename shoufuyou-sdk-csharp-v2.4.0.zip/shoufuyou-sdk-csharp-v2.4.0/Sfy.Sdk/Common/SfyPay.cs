﻿
namespace Sfy.Sdk
{
    public static class SfyPay
    {
        /// <summary>
        /// 通知地址数据校验
        /// </summary>
        /// <returns></returns>
        public static SfyNotifyResult NotifyVerify()
        {
            return SfyUtil.Verify();
        }

        /// <summary>
        /// 网关模式下的页面回调地址数据校验
        /// </summary>
        /// <returns></returns>
        public static SfyNotifyResult ReturnVerify()
        {
            return SfyUtil.Verify();
        }
    }
}
