﻿using System.Collections.Generic;

namespace Sfy.Sdk
{
    public static class SfyApi
    {
        /// <summary>
        /// 首付游收单接口（网关模式）
        /// </summary>
        /// <param name="reqParams"></param>
        public static SfyRspResult<T> TradeCreate<T>(Dictionary<string, object> reqParams)
        {
            return Invoke<T>(reqParams, ReqType.TradeCreate);
        }

        /// <summary>
        /// 首付游放款请求接口
        /// </summary>
        /// <param name="reqParams"></param>
        public static SfyRspResult<T> TradeLoan<T>(Dictionary<string, object> reqParams)
        {
            return Invoke<T>(reqParams, ReqType.TradeLoan);
        }

        /// <summary>
        /// 首付游交易查询接口
        /// </summary>
        /// <param name="reqParams"></param>
        public static SfyRspResult<T> TradeQuery<T>(Dictionary<string, object> reqParams)
        {
            return Invoke<T>(reqParams, ReqType.TradeQuery);
        }

        /// <summary>
        /// 首付游退款请求接口
        /// </summary>
        /// <param name="reqParams"></param>
        public static SfyRspResult<T> TradeRefund<T>(Dictionary<string, object> reqParams)
        {
            return Invoke<T>(reqParams, ReqType.TradeRefund);
        }

        /// <summary>
        /// 首付游退款请求接口
        /// </summary>
        /// <param name="reqParams"></param>
        public static SfyRspResult<T> TradeRefundQuery<T>(Dictionary<string, object> reqParams)
        {
            return Invoke<T>(reqParams, ReqType.TradeRefundQuery);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqParams"></param>
        /// <param name="reqType"></param>
        /// <returns></returns>
        private static SfyRspResult<T> Invoke<T>(Dictionary<string, object> reqParams, ReqType reqType)
        {
            var invoke = new ExecutorForSfy<T>();
            return invoke.Invoke(reqParams, reqType);
        }
    }
}
