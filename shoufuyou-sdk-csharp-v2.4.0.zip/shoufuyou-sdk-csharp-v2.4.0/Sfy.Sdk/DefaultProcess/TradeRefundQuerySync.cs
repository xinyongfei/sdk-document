﻿using System;
using System.Collections.Generic;

namespace Sfy.Sdk
{
    /// <summary>
    /// 首付游退款请求接口
    /// </summary>
    internal sealed class TradeRefundQuerySync : RequestBase<string, string>
    {
        /// <summary>
        /// 商户请求首付游给某个订单退款
        /// </summary>
        /// <param name="reqContent"></param>
        /// <returns></returns>
        protected override string DoDeal(string reqContent)
        {
            throw new NotImplementedException();
        }

        #region 【查检请求数据参数】

        /// <summary>
        /// 
        /// </summary>
        private static readonly Dictionary<string, string> Dicts = new Dictionary<string, string>()
        {
            {"merchant_refund_id","商户退款流水号"},
        };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reqParams"></param>
        /// <returns></returns>
        protected override SfyCustomResult CheckReqParamters(Dictionary<string, object> reqParams)
        {
            var header = this.CheckHeaderParamters();
            if (!header.IsSuccess) return header;

            var result = new SfyCustomResult()
            {
                Code = "50001"
            };

            if (reqParams == null || reqParams.Count <= 0)
            {
                result.Message = "请求的退款查询请求接口参数不能为空.";
                return result;
            }

            foreach (var dict in Dicts)
            {
                switch (dict.Key)
                {
                    case "refund_amount": // 退款金额
                        if (SfyUtil.IsEmptyInt(result, reqParams, dict))
                        {
                            return result;
                        }
                        break;
                    default:
                        if (SfyUtil.IsEmptyStr(result, reqParams, dict))
                        {
                            return result;
                        }
                        break;
                }
            }
            result.IsSuccess = true;
            return result;
        }
        #endregion
    }
}
