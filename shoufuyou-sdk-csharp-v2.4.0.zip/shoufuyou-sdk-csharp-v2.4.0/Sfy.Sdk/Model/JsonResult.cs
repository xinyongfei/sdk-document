﻿
namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    internal class RspResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string biz_content { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string charset { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string merchant_code { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string method { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string sign { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string timestamp { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string version { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    internal class JsonResult
    {
        /// <summary>
        /// 返回的结果码
        /// </summary>
        public string code { get; set; }

        /// <summary>
        /// 返回结果码对应的字符串解释
        /// </summary>
        public string message { get; set; }

        /// <summary>
        /// 商户订单号
        /// </summary>
        public string merchant_order_id { get; set; }

        /// <summary>
        /// 首付游交易号
        /// </summary>
        public string trade_number { get; set; }

        /// <summary>
        /// 订单状态
        /// </summary>
        public string trade_status { get; set; }

        /// <summary>
        /// 首付游账单链接
        /// </summary>
        public string bill_url { get; set; }

        /// <summary>
        /// 首付游订单总金额
        /// </summary>
        public string order_amount { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    internal class JsonRefundResult
    {
        /// <summary>
        /// 返回的结果码
        /// </summary>
        public string code { get; set; }

        /// <summary>
        /// 返回结果码对应的字符串解释
        /// </summary>
        public string message { get; set; }

        /// <summary>
        /// 商户订单号
        /// </summary>
        public string merchant_order_id { get; set; }

        /// <summary>
        /// 商户退款流水号
        /// </summary>
        public string merchant_refund_id { get; set; }

        /// <summary>
        /// 该订单本次退款金额
        /// </summary>
        public string refund_amount { get; set; }

        /// <summary>
        /// 该订单已退款金额
        /// </summary>
        public string refund_total_amount { get; set; }

    }
}
