﻿namespace Sfy.Sdk
{
    /// <summary>
    /// 
    /// </summary>
    public class SfyCustomResult
    {
        /// <summary>
        /// 
        /// </summary>
        internal bool IsSuccess { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string Code { set; get; }

        /// <summary>
        /// 
        /// </summary>
        public string Message { set; get; }
    }

    /// <summary>
    /// 
    /// </summary>
    public sealed class SfyRspResult<T> : SfyCustomResult
    {
        /// <summary>
        /// 
        /// </summary>
        public T Data { set; get; }
    }
}
