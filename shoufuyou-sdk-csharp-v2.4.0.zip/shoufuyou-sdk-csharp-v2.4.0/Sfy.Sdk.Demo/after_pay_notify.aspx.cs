﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sfy.Sdk.Demo
{
    public partial class after_pay_notify : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var result = SfyPay.NotifyVerify();

            if (result.TradeStatus == "PAY_SUCCESS")
            {
                // 支付成功，此处执行支付成功业务逻辑

            }
            else
            {
                // 支付失败，此处执行支付失败业务逻辑

            }
            Response.Write("SUCCESS");
        }
    }
}