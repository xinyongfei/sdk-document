﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Sfy.Sdk.Demo.Startup))]
namespace Sfy.Sdk.Demo
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) { ConfigureAuth(app);
        }
    }
}
