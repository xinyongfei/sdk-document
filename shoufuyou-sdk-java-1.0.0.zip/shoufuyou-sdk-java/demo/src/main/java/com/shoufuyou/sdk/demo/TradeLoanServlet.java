package com.shoufuyou.sdk.demo;

import java.io.IOException;
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import com.shoufuyou.sdk.*;

//放款
@SuppressWarnings("serial")
public class TradeLoanServlet extends HttpServlet implements javax.servlet.Servlet{ 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        SfyClient client = SfyClientFactory.createSfyClient();
        TradeLoanRequest tlr = new TradeLoanRequest();
        tlr.setMerchantOrderId("5789651321512312");
        tlr.setTradeNumber("201604061310051914");
        tlr.setNotifyUrl("http://hostname:8080/shoufuyou-sdk-demo/after-loan-notify");
        TradeLoanResponse res = client.sendTradeLoanRequest(tlr);
        System.out.println(res.getMerchantOrderId());
        System.out.println(res.getTradeNumber());
        System.out.println(res.getTradeStatus());
        System.out.println(res.getBillUrl());
    }
}
