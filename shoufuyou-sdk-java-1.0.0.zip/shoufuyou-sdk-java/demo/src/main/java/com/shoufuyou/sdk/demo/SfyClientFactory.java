package com.shoufuyou.sdk.demo;

import com.shoufuyou.sdk.*;

//创建 SfyClient
public class SfyClientFactory {
    public static SfyClient createSfyClient() {
        SfyConfig config = new SfyConfig();
        config.setMerchantCode("1000000000");//商户号
        config.setPrivateKey("012345678901234567890123");//商户私钥
        config.setApiUrl("http://apitest.shoufuyou.com/service");//首付游 api url
        config.setPayUrl("http://test1-pay-mobile.shoufuyou.com/");//首付游支付 url
        SfyClient client = new SfyClient(config);
        return client;
    }
}
