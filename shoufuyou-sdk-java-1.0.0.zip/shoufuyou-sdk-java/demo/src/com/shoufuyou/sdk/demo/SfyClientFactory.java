package com.shoufuyou.sdk.demo;

import com.shoufuyou.sdk.*;

public class SfyClientFactory {
    public static SfyClient createSfyClient() {
        SfyConfig config = new SfyConfig();
        config.setMerchantCode("1000000000");
        config.setPrivateKey("012345678901234567890123");
        config.setApiUrl("http://apitest.shoufuyou.com/service");
        config.setPayUrl("http://test1-pay-mobile.shoufuyou.com/");
        SfyClient client = new SfyClient(config);
        return client;
    }
}
