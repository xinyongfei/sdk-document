package com.shoufuyou.sdk;

public class TradeLoanRequest extends TradeRequest {
    private String notifyUrl;

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }
}