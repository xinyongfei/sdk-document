package com.shoufuyou.sdk;

public class TradeLoanResponse extends TradeResponse {
    private String billUrl;

    public String getBillUrl() {
        return billUrl;
    }

    public void setBillUrl(String billUrl) {
        this.billUrl = billUrl;
    }
}