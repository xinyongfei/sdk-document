package com.shoufuyou.sdk;

public class TradeQueryResponse extends TradeResponse {
}