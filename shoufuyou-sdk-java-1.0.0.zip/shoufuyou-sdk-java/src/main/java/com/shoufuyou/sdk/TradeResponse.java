package com.shoufuyou.sdk;

public abstract class TradeResponse {
    private String merchantOrderId;
    private String tradeNumber;
    private TradeStatus tradeStatus;

    public String getMerchantOrderId() {
        return merchantOrderId;
    }

    public String getTradeNumber() {
        return tradeNumber;
    }

    public void setTradeNumber(String tradeNumber) {
        this.tradeNumber = tradeNumber;
    }

    public void setMerchantOrderId(String merchantOrderId) {
        this.merchantOrderId = merchantOrderId;
    }

    public TradeStatus getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(TradeStatus tradeStatus) {
        this.tradeStatus = tradeStatus;
    }
}