package com.shoufuyou.sdk;

public class TradeRefundResponse extends TradeResponse {
}