package com.shoufuyou.sdk;

public class TradeQueryRequest extends TradeRequest {
}